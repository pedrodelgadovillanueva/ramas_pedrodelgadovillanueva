
export interface AuthResponse {
    id?: string ;
    token: string;
    email: string;
    password:  string;
    msg?: string
}


