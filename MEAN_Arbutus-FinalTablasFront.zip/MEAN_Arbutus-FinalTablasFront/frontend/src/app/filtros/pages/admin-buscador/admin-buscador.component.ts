import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-buscador',
  templateUrl: './admin-buscador.component.html',
  styleUrls: ['./admin-buscador.component.css']
})
export class AdminBuscadorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
