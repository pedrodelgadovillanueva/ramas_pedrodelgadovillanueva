import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-por-estado',
  templateUrl: './por-estado.component.html',
  styleUrls: ['./por-estado.component.css']
})
export class PorEstadoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
