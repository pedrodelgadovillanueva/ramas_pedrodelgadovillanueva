import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ver-especie',
  templateUrl: './ver-especie.component.html',
  styleUrls: ['./ver-especie.component.css']
})
export class VerEspecieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
