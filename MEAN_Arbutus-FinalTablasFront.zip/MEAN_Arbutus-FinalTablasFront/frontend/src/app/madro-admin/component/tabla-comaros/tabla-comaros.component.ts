import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabla-comaros',
  templateUrl: './tabla-comaros.component.html',
  styleUrls: ['./tabla-comaros.component.css']
})
export class TablaComarosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
