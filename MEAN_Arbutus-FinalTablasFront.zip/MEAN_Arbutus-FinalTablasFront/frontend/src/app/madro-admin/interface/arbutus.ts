export interface Arbutus {
  id?: string ;
  especie: string;
  estado:  string;
  habito:  string;
  corteza_ramas: string;
  corteza_ramillas: string;
  peciolos: string;
  hojas: string;
  haz: string;
  envez: string;
  flores: string;
  imagen: string;
}
