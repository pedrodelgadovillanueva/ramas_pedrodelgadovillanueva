export interface Comarostaphylis {
  id?: string ;
  especie: string;
  estado:  string;
  habito:  string;
  peciolos_ramillas: string;
  hojas_Duracion_textura: string;
  hojas_Anchas: string;
  hojas_Margen: string;
  hojas_Enves: string;
  inflorescencia: string;
  flores: string;
  imagen: string;
}
