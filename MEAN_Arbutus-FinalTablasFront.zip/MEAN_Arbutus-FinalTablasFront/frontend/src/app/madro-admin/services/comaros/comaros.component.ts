import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comaros',
  templateUrl: './comaros.component.html',
  styleUrls: ['./comaros.component.css']
})
export class ComarosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
