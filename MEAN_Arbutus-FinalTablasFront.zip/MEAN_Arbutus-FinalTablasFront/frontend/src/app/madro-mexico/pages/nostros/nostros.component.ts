import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nostros',
  templateUrl: './nostros.component.html',
  styleUrls: ['./nostros.component.css']
})
export class NostrosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
